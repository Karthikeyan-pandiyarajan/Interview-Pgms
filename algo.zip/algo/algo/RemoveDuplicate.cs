﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace algo
{
	public class RemoveDuplicate
	{
		public static string RemoveDuplicateString(string input)
		{
			string table = string.Empty;
			string result = string.Empty;

			foreach(char value in input)
			{
				if(table.IndexOf(value) == -1)
				{
					table += value;
					result += value;
				}
			}
			return result;
		}

		public static string Reverse(string input)
		{
			string result = string.Empty;
			for(int i = input.Length -1; i >=0; i--)
			{
				result += input[i];
			}
			return result;
		}

		public static void DisplayReverse(string str)
		{
			if (str.Length > 0)
				DisplayReverse(str.Substring(1, str.Length - 1));
			else
				return;
			Console.WriteLine(str[0]);
		}

		public static void Recursion(string str)
		{
			if (str.Length > 0)
			{
				Recursion(str.Substring(1, str.Length - 1));
			}
			else
				return;
			Console.WriteLine(str[0]);
		}

		public static void DisplaySubstring(string str)
		{
			for(int length = 0; length< str.Length; length++)
			{
				for (int start = 0; start < str.Length - length; start++)
				{
					Console.WriteLine(str.Substring(start, length));
				}
			}
		}
	}
}
