﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace algo
{
	class Program
	{
		static void Main(string[] args)
		{
			//const string pattern1 = "Latha";
			//const string input = "He and 'she' are my Dad friends";
			//var regExpr1 = new Regex("\'.*\'", RegexOptions.IgnoreCase);
			//var result1= regExpr1.Replace(input, pattern1);

			string str = "'Hari, CIA, CSS', 'KARTHI, CAA, CST'";
			string pattern = @"',";
			string result = Regex.Replace(str, pattern, "*", RegexOptions.None);
			var ee = result.Split('*');
			//if (checkPangram(str) == true)
			//	Console.WriteLine(str + " is a pangram.");
			//else
			//	Console.WriteLine(str + " is not a pangram.");
			int[] t = new int[] { 1, 9, 6, 7, 5, 9 };
			//ArrayDemo.SortArray();
			//foreach(var c in ArrayDemo.SortArray(t))
			//{
			//	Console.WriteLine(c);
			//}
			//Console.WriteLine(ArrayDemo.FindMinimumDistance(t, 2, 5));
			//int[] a = { 1, 2, 4, 5, 6 };
			//int miss = getMissingNo(a, 5);
			//Console.Write(miss);
			int val = 5;
			int i, j, k;
			for (i = 1; i <= val; i++)
			{
				for (j = 1; j <= i; j++)
				{
					Console.Write("");
				}
				for (k = 1; k <= i; k++)
				{
					Console.Write("*");
				}
				Console.WriteLine("");
			}
			Console.ReadLine();
		}

		static int getMissingNo(int[] a, int n)
		{
			int total = (n + 1) * (n + 2) / 2;

			for (int i = 0; i < n; i++)
				total -= a[i];

			return total;
		}



		private static bool checkPangram(string inputStr)
		{
			bool[] mark = new bool[26];
			int index = 0;

			for(int i = 0; i< inputStr.Length; i++)
			{
				if ('A' <= inputStr[i] && inputStr[i] <= 'Z')
				{
					index = inputStr[i] - 'A';
				}
				else if ('a' <= inputStr[i] && inputStr[i] <= 'z')
				{
					index = inputStr[i] - 'a';
				}
				else
					continue;

				mark[index] = true;
			}

			for(int j=0; j<=25; j++)
			{
				if (mark[j] == false)
					return false;
			}

			return false;
		}


	}
}
