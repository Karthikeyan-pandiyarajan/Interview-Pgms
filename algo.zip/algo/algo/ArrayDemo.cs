﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace algo
{
	public class ArrayDemo
	{

		public static bool CheckIntPresentSumOfTwoIntegers(int[] inputArr, int target)
		{
			int result = 0;
			for (int i = 0; i < inputArr.Length; i++)
			{
				for (int j = 0; j < inputArr.Length; j++)
				{
					if (i != j)
					{
						result = inputArr[i] + inputArr[j];
						if (result == target)
							return true;
					}

				}

			}

			return false;
		}

		public static int[] seggregate(int[] inpuarr)
		{
			int[] temp = new int[inpuarr.Length];
			int index = 0;
			for (int i = 0; i < inpuarr.Length; i++)
			{
				if (inpuarr[i] >= 0)
				{
					temp[index++] = inpuarr[i];
				}
			}

			if (index == 0 || index == inpuarr.Length)
				return inpuarr;

			for (int i = 0; i < inpuarr.Length; i++)
			{
				if (inpuarr[i] < 0)
				{
					temp[index++] = inpuarr[i];
				}
			}
			return temp;
		}

		public static void SortArray()
		{
			int[] arr = new int[] { 1, 9, 6, 7, 5, 9 };

			int temp;

			// traverse 0 to array length 
			for (int i = 0; i < arr.Length - 1; i++)
			{
				for (int j = i + 1; j < arr.Length; j++)
				{
					if (arr[i] > arr[j])
					{

						temp = arr[i];
						arr[i] = arr[j];
						arr[j] = temp;
					}
				}
			}

			// print all element of array 
			foreach (int value in arr)
			{
				Console.Write(value + " ");
			}
		}

		public static int FindMinimumDistance(int[] input, int x, int y)
		{
			int result = 0;
			bool canCheckStarted = false;
			for (int i = 0; i < input.Length; i++)
			{
				if (!canCheckStarted)
				{
					if (input[i] == x)
					{
						result++;
						canCheckStarted = true;
					}
				}
				else
				{
					if (input[i] == y)
						return result;
					result++;
				}
			}
			return result;
		}
	}
}
